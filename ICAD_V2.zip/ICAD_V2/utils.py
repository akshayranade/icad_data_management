
from datetime import datetime, timedelta

def to_date(value):
    if value is None:
        return None
    if isinstance(value, float) and value != value:  # NaN
        return None
    s = str(value).strip()
    if not s:
        return None
    # Try common formats
    for fmt in ("%Y-%m-%d","%d-%m-%Y","%d/%m/%Y","%Y/%m/%d","%d-%b-%Y","%Y.%m.%d"):
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            continue
    # Excel serial?
    try:
        base = datetime(1899,12,30)
        days = float(s)
        return (base + timedelta(days=days)).date()
    except Exception:
        pass
    return None

def to_numeric(value):
    if value is None:
        return None
    if isinstance(value, float) and value != value:  # NaN
        return None
    s = str(value).strip().replace(",","")
    if s == "":
        return None
    try:
        return float(s)
    except ValueError:
        return None
