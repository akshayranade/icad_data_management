import os
import argparse
import pandas as pd
from db import upsert_rows, ensure_tracker_table, ensure_schema
from io_utils import read_any, standardize_columns, coerce_types, sanitize_rows
from processors import compute_name_key,enrich_with_master_school

# -------------------------------------------------------------------
# Safe Upsert Helper
# -------------------------------------------------------------------

def safe_upsert_student_admissions(conn, df):
    """Upsert rows into student_admissions, skipping any without student_id."""
    # print("safe_upsert_student_admissions",type(df), df)
    if "student_id" not in df.columns:
        return
    df = df[df["student_id"].notnull()]   # ✅ drop bad rows
    if df.empty:
        return

    upsert_rows(
        conn,
        "student_admissions",
        sanitize_rows(df.to_dict(orient="records")),
        ["student_id"]
    )

# -------------------------------------------------------------------
# Transactional processors
# -------------------------------------------------------------------

def process_student_file(conn, df):
    cur = conn.cursor()
    cur.execute("SELECT name_key, student_id FROM student;")
    existing = dict(cur.fetchall())
    next_id = max(existing.values(), default=0) + 1

    new_rows = []
    for row in df.to_dict(orient="records"):
        # Ensure name_key always exists
        student_name = str(row.get("student_name", "")).strip().lower()
        school_name = str(row.get("school", "")).strip().lower()
        nk = student_name + ("_" + school_name if school_name else "")
        row["name_key"] = nk

        # Match or assign ID
        if nk in existing:
            row["student_id"] = existing[nk]
        else:
            row["student_id"] = next_id
            existing[nk] = next_id
            next_id += 1

        new_rows.append(row)

    df = pd.DataFrame(new_rows)
    school_master_df =  pd.read_sql("SELECT * FROM school;", conn)

    df = enrich_with_master_school(df, school_master_df)
    df = df.drop(columns=["standard_school_city", "standard_school_addr", "branch_name"])


    # Insert/update student table
    upsert_rows(conn, "student", sanitize_rows(df.to_dict(orient="records")), ["student_id"])
    # print("***********")
    print("Student Records updated in Students table")

    # Insert into student_admissions with admission_id NULL
    admissions_df = df[["student_id", "name_key", "school", "exam"]].copy()
    admissions_df["admission_id"] = None
    safe_upsert_student_admissions(conn, admissions_df)

    conn.commit()


def process_admission_file(conn, df):
    df["admission_id"] = df["roll_no"]
    df["admission_id"] = df["admission_id"].astype("Int64")  # nullable int type


    df = df.drop(columns=["roll_no"], errors="ignore")

    cur = conn.cursor()
    cur.execute("SELECT name_key, student_id FROM student;")
    existing = dict(cur.fetchall())
    next_id = max(existing.values(), default=0) + 1
    new_rows = []
    for row in df.to_dict(orient="records"):
        # Ensure name_key always exists
        student_name = str(row.get("student_name", "")).strip().lower()
        school_name = str(row.get("school", "")).strip().lower()
        nk = student_name + ("_" + school_name if school_name else "")
        row["name_key"] = nk

        # Match or assign ID
        if nk in existing:
            row["student_id"] = existing[nk]
        else:
            row["student_id"] = next_id
            existing[nk] = next_id
            next_id += 1

        new_rows.append(row)

    df = pd.DataFrame(new_rows)
    school_master_df =  pd.read_sql("SELECT * FROM school;", conn)

    df = enrich_with_master_school(df, school_master_df)
    df = df.drop(columns=["student_id","branch_name"])

    # Insert/update admission table
    upsert_rows(conn, "admission", sanitize_rows(df.to_dict(orient="records")), ["admission_id"])

    cur = conn.cursor()
    records = []
    for row in df.to_dict(orient="records"):
        nk = row.get("name_key")

        # Lookup student
        cur.execute("SELECT student_id FROM student WHERE name_key=%s;", (nk,))
        res = cur.fetchone()
        if res:
            student_id = res[0]
        else:
            # Create new student if not exists
            cur.execute("SELECT COALESCE(MAX(student_id),0)+1 FROM student;")
            student_id = cur.fetchone()[0]
            cur.execute(
                "INSERT INTO student (student_id, student_name, name_key, school) VALUES (%s,%s,%s,%s);",
                (student_id, row.get("student_name"), nk, row.get("school"))
            )
        row["student_id"] = student_id
        # if "student_name" in row:
        #     del row["student_name"]
        # print(row)
        records.append(row)

    admissions_df = pd.DataFrame(records)
    admissions_df["admission_id"] = admissions_df["admission_id"].astype("Int64")

    # print("admissions_df",admissions_df.iloc[0])

    school_master_df =  pd.read_sql("SELECT * FROM school;", conn)

    admissions_df = enrich_with_master_school(admissions_df, school_master_df)

    # print("admissions_df after enriching",admissions_df.iloc[0])
    # Update/insert into student_admissions
    print("\n\n flow is here")
    safe_upsert_student_admissions(conn, admissions_df)

    conn.commit()

# -------------------------------------------------------------------
# Main orchestration
# -------------------------------------------------------------------

def process_file(conn, cfg, schema_yaml, fpath: str, reprocess: bool=False):
    tracker_table = cfg.get("tracker_table", "public.processed_files")
    ensure_tracker_table(conn, tracker_table)

    # Read file
    df = read_any(fpath, cfg.get('ingest_hints'))
    df = standardize_columns(df, cfg["standard_columns"])
    df = coerce_types(df, cfg.get("column_types", {}))

    # Compute name_key if missing
    if "student_name" in df.columns:
        df["student_name"] = df["student_name"].fillna("").astype(str).apply(lambda s: s.strip())
        df = compute_name_key(df)
    if "name_key" not in df.columns:
        df["name_key"] = None

    # Route by filename
    fname = os.path.basename(fpath).lower()
    if "student" in fname:
        process_student_file(conn, df)
    elif "admission" in fname:
        process_admission_file(conn, df)
    else:
        print(f"SKIP: Unknown file type for {fpath}")
        return 0

    # Mark file as processed
    import hashlib
    h = hashlib.md5(open(fpath, "rb").read()).hexdigest()
    cur = conn.cursor()
    cur.execute(f"""
        INSERT INTO {tracker_table} (file_path, file_hash, rows_loaded, notes)
        VALUES (%s, %s, %s, %s)
        ON CONFLICT (file_hash) DO UPDATE SET
          processed_at = now(),
          rows_loaded = EXCLUDED.rows_loaded;
    """, (str(fpath), h, len(df), None))
    conn.commit()

    return len(df)


def run_pipeline(cfg, schema_yaml, reprocess=False):
    import psycopg2
    conn = psycopg2.connect(
        host=cfg["postgres"]["host"],
        port=cfg["postgres"]["port"],
        user=cfg["postgres"]["user"],
        password=cfg["postgres"]["password"],
        dbname=cfg["postgres"]["dbname"],
    )

    ensure_schema(conn, schema_yaml)

    # Process all files in input folder
    import glob
    for fpath in glob.glob(os.path.join(cfg["input_folder"], "*")):
        print(f"Processing {fpath}...")
        process_file(conn, cfg, schema_yaml, fpath, reprocess)

    conn.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=["run"])
    parser.add_argument("--config", required=True)
    parser.add_argument("--schema", required=True)
    parser.add_argument("--reprocess", action="store_true")
    args = parser.parse_args()

    import yaml
    with open(args.config) as f:
        cfg = yaml.safe_load(f)
    with open(args.schema) as f:
        schema_yaml = yaml.safe_load(f)

    if args.command == "run":
        run_pipeline(cfg, schema_yaml, reprocess=args.reprocess)
