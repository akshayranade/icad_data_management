
import hashlib
from pathlib import Path

def file_hash(path: str, chunk_size: int = 1_048_576) -> str:
    """Compute SHA256 of a file for dedup/reprocessing checks."""
    h = hashlib.sha256()
    p = Path(path)
    with p.open("rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()

import pandas as pd

def read_any(fpath, hints=None):
    """Read a CSV or Excel file into a pandas DataFrame."""
    print(fpath)
    if fpath.lower().endswith(".csv"):
        # Try different encodings for CSV files
        encodings = ['utf-8', 'latin-1', 'cp1252', 'iso-8859-1']
        for encoding in encodings:
            try:
                return pd.read_csv(fpath, encoding=encoding)
            except UnicodeDecodeError:
                continue
        # If all encodings fail, raise the original error
        return pd.read_csv(fpath)
    elif fpath.lower().endswith(".xlsx") or fpath.lower().endswith(".xls"):
        return pd.read_excel(fpath)
    else:
        raise ValueError(f"Unsupported file type: {fpath}")

def standardize_columns(df, standard_columns):
    """
    Ensure dataframe has expected columns.
    - Rename columns to lowercase/underscores.
    - Fill missing expected columns with None.
    """
    # Clean headers
    df.columns = [str(c).strip().lower().replace(" ", "_") for c in df.columns]

    # If no proper list provided, skip
    if not isinstance(standard_columns, (list, tuple)):
        return df

    for col in standard_columns:
        if col not in df.columns:
            df[col] = None
    return df


def coerce_types(df, type_map):
    """Cast dataframe columns to given types."""
    for col, dtype in type_map.items():
        if col in df.columns:
            try:
                df[col] = df[col].astype(dtype)
            except Exception:
                pass
    return df

def sanitize_rows(rows):
    """Convert NaN/NaT to None for DB inserts."""
    clean_rows = []
    for r in rows:
        clean = {k: (None if pd.isna(v) else v) for k, v in r.items()}
        clean_rows.append(clean)
    return clean_rows
