
import psycopg2
import psycopg2.extras
import pandas as pd

def sanitize_rows(rows):
    clean_rows = []
    for r in rows:
        if isinstance(r, dict):
            clean_rows.append({k: (None if pd.isna(v) else v) for k, v in r.items()})
        else:
            clean_rows.append(tuple(None if pd.isna(v) else v for v in r))
    return clean_rows

def get_conn(cfg):
    return psycopg2.connect(
        host=cfg["postgres"]["host"],
        port=cfg["postgres"]["port"],
        user=cfg["postgres"]["user"],
        password=cfg["postgres"]["password"],
        dbname=cfg["postgres"]["dbname"],
    )

def ensure_tracker_table(conn, tracker_table: str):
    with conn, conn.cursor() as cur:
        cur.execute(f"""
        CREATE TABLE IF NOT EXISTS {tracker_table} (
            id bigserial primary key,
            file_path text not null,
            file_hash text not null,
            processed_at timestamptz not null default now(),
            rows_loaded int,
            notes text,
            unique(file_hash)
        );
        """)

def table_exists(conn, schema, table):
    with conn, conn.cursor() as cur:
        cur.execute("""
        SELECT 1
        FROM information_schema.tables
        WHERE table_schema=%s AND table_name=%s
        """, (schema, table))
        return cur.fetchone() is not None

def create_table(conn, tname: str, tdef: dict):
    schema = tdef.get("schema","public")
    cols = tdef["columns"]
    pks = tdef.get("primary_key", [])
    col_sql = ",\n  ".join([f"{c} {t}" for c,t in cols.items()])
    pk_sql = f",\n  PRIMARY KEY({', '.join(pks)})" if pks else ""
    sql = f"CREATE TABLE IF NOT EXISTS {schema}.{tname} (\n  {col_sql}{pk_sql}\n);"
    with conn, conn.cursor() as cur:
        cur.execute(sql)

def ensure_schema(conn, schema_yaml: dict):
    tables = schema_yaml.get("tables", {})
    for name, tdef in tables.items():
        schema = tdef.get("schema","public")
        if not table_exists(conn, schema, name):
            create_table(conn, name, tdef)

def upsert_rows(conn, table: str, rows: list, pk_cols: list):
    print("before sanitize",rows)
    if not rows:
        return 0
    rows = sanitize_rows(rows)
    print("after sanitize",rows)
    cols = list(rows[0].keys())
    if "." in table:
        schema, name = table.split(".",1)
    else:
        schema, name = "public", table
    target = f"{schema}.{name}"

    placeholders = ", ".join([f"%({c})s" for c in cols])
    insert_cols = ", ".join(cols)
    conflict = ", ".join(pk_cols) if pk_cols else None
    updates = ", ".join([f"{c}=EXCLUDED.{c}" for c in cols if c not in pk_cols])

    if conflict:
        sql = f"""
        INSERT INTO {target} ({insert_cols})
        VALUES ({placeholders})
        ON CONFLICT ({conflict})
        DO UPDATE SET {updates};
        """
        print(sql)
    else:
        sql = f"""
        INSERT INTO {target} ({insert_cols})
        VALUES ({placeholders});
        """
        print(sql)

    with conn, conn.cursor() as cur:
        psycopg2.extras.execute_batch(cur, sql, rows, page_size=1000)
    return len(rows)
