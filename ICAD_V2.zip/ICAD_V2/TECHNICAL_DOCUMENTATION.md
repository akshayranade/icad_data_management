# Technical Documentation

## Project Structure
- `main.py` : Entry point, orchestrates ingestion pipeline.
- `config.yaml` : Config (DB connection, targets, column mappings).
- `schema.yaml` : Defines DB schema for all tables.
- `processors.py`, `io_utils.py`, `db.py`, `helpers/` : Utility modules.
- `examples/` : Sample input files.
- `sql/` : SQL bootstrap scripts.

## Ingestion Flow
1. **File detection**  
   - If filename contains "student" → process as student file.  
   - If filename contains "admission" → process as admission file.

2. **Student file ingestion**
   - Read CSV: `student_name, school, class, exam`.
   - Compute `name_key = clean(student_name + school)`.
   - Deduplicate on `name_key`.
   - If existing student found → reuse `student_id`.
   - Else assign new `student_id`.
   - Insert into `student`.
   - Insert into `student_admissions` with `admission_id=NULL`.

3. **Admission file ingestion**
   - Read Excel (~43 cols).
   - Standardize column names (ROLL NO → admission_id, Students Name On Roll → student_name, etc.).
   - Insert into `admission` table.
   - Compute `name_key`.
   - Match against student:
     - If found → update row in `student_admissions`.
     - If not found → create new student then insert mapping.
   - Enrich with school master.

4. **Enrichment**
   - `school` master provides standardized name/id/address/city.
   - Lookup performed in code (`maybe_enrich_with_master`).

5. **Student_admissions refresh**
   - SQL join of student + admission + school.
   - Updates all columns used in PowerBI.
   - Ensures consistency after each run.

## Deduplication & Keys
- `student`: PK = `student_id` (generated). Deduplication via `name_key`.
- `admission`: PK = `admission_id` (Excel ROLL NO).
- `student_admissions`: PK = `student_id`. Allows admission_id=NULL until updated.

## Error Handling
- Files tracked by hash in `processed_files` to avoid reprocessing.
- Use `--reprocess` flag to force re-run.

## Debugging Tips
- To inspect a processed file: check `processed_files` table.
- To trace duplicates: query `student` grouped by `name_key`.
- To reset pipeline: clear target tables + tracker.

## Extensibility
- To add new student/admission columns:
  - Update `schema.yaml`.
  - Update `config.yaml` targets.
  - Adjust column mappings in `config.yaml:standard_columns`.

