
# ICAD Data Ingestion Pipeline

This package loads student, admission, and school data from Excel/CSV files into PostgreSQL,
with cleaning, standardization, and school-matching built in.

---

## 📦 Project Structure

```
icad_ingest/
├── main.py                 # Entry point (CLI)
├── processors.py           # Data cleaning, exam derivation, header auto-fix
├── db.py                   # Database helpers
├── io_utils.py             # File hashing utils
├── helpers/                # Cleaners and matching helpers
│   ├── clean_column_names.py
│   ├── clean_strings.py
│   ├── get_master_school.py
│   ├── similarity_cosine_str_list.py
│   ├── similarity_jaro_str_list.py
├── sql/
│   ├── bootstrap_tables.sql  # Create all Postgres tables
│   ├── seed_school.sql       # Load seeds/school.csv into public.school
├── seeds/
│   └── school.csv            # Fill with school master data
├── input/                  # Drop new files here (CSV/XLSX)
├── config.yaml             # Main configuration (DB credentials, mappings)
├── schema.yaml             # Target schema definition
├── requirements.txt        # Python dependencies
└── README_CLIENT.md        # This file
```

---

## 🚀 First-Time Setup

1. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

2. **Prepare PostgreSQL tables**
   ```bash
   # Creates student, admission, school, student_admissions
   psql -h 127.0.0.1 -p 5432 -U postgres -d postgres -f sql/bootstrap_tables.sql
   ```

3. **Seed school master**
   - Fill `seeds/school.csv` with your school master data (keep headers intact).
   - Run:
     ```bash
     psql -h 127.0.0.1 -p 5432 -U postgres -d icad_v2_db -f sql/seed_school.sql
     ```
     ```
     SET PGPASSWORD=admin
     psql -h 127.0.0.1 -p 5432 -U postgres -d icad_v2_db -c "\copy student(student_id, student_name, standard_school_name, standard_school_id, class, exam, name_key) FROM 'seeds/student_existing.csv' CSV HEADER"
     psql -h 127.0.0.1 -p 5432 -U postgres -d icad_v2_db -c "UPDATE student SET school = standard_school_name WHERE school IS NULL;"
     psql -h 127.0.0.1 -p 5432 -U postgres -d icad_v2_db -c "\copy admission FROM 'seeds/admission_existing.csv' CSV HEADER"
     psql -h 127.0.0.1 -p 5432 -U postgres -d icad_v2_db -c "\copy student_admissions FROM 'seeds/student_admissions_existing_final.csv' CSV HEADER"
     ```

4. **Configure connection**
   Edit `config.yaml` → update `postgres` credentials and `db_details`.

---

## 📂 Input File Format (Standardized)

- **Supported:** CSV (`.csv`) and Excel (`.xlsx`)
- **Required headers:**
  - `admission_id`, `student_name`, `branch`, `batch`, `on_roll1`, `category`, `school`, `xi_college`, `board_in_10th`, `board_in_11th_std`, `class`, `exam`
- **Exam columns:** either a single `exam` column with comma-joined values, or multiple Yes/No exam columns (configured in `config.yaml → exam_columns`).
- **Cleaning rules:** 
  - `school`: commas replaced with spaces, matched to school master.
  - `student_name`, `city`, `school`: normalized with `clean_string_data`.
  - `class`: “10th”, “9th”, “-” → converted to integer or null.

See `examples/example_input.csv` for a template.

---

## ⚙️ Handling Old / Mixed Files

The pipeline auto-detects **CPA-style multi-row headers** (lots of “Unnamed: *” columns).
- It will re-read with row 3 as header if needed.
- If a specific file is tricky, add a rule in `config.yaml`:

```yaml
ingest_hints:
  cpa_master:
    match: "cpa results"   # substring of filename
    header_row: 2          # 0-based index (2 => third row)
```

---

## ▶️ Running the Pipeline

1. Place new files in `input/`.
2. Run:
   ```bash
   python main.py run
   ```
   - Processes only new files (tracked by hash).
   - Cleans, standardizes, enriches with school master, and loads into Postgres.

3. To force reprocess a file:
   ```bash
   python main.py run --reprocess
   ```

---

## 🗄️ Database Outputs

- **student** → cleaned student data (`student_name`, `standard_school_*`, `class`, `exam`)
- **admission** → admissions data with standardized school reference
- **school** → seeded master data from `seeds/school.csv`
- **student_admissions** → joined dataset (admission × student × school), incl. exam counts

---

## 🔧 Maintenance Notes

- Update `school.csv` as school master grows, then re-run `seed_school.sql`.
- For new exam types, either:
  - add them directly as Yes/No columns in data, update `exam_columns` in `config.yaml`
  - or join them manually into a single `exam` column before upload.

---

## ✅ Example Workflow

```bash
# 1. Create tables
psql -d icad -f sql/bootstrap_tables.sql

# 2. Seed schools
psql -d icad -f sql/seed_school.sql

# 3. Drop raw Excel into input/
cp ~/Downloads/1."Admission - 2026 Batch.xlsx" input/

# 4. Run pipeline
python main.py run --config config.yaml --schema schema.yaml
```

---

Happy data loading 🎉


---

## 📑 Example Input File

An example input CSV is included at:
```
examples/example_input.csv
```

This demonstrates the required column headers and a couple of dummy rows.
Clients can copy this format and fill in their own data for uploads.


---

## 📁 Examples
Two sample input files are provided in `examples/`:

1) `example_input.csv`  
   - Uses a single `exam` column with comma-separated values.

2) `example_input_with_yesno.csv`  
   - Uses per-exam Yes/No flags. To enable, set in `config.yaml`:
     ```yaml
     exam_columns:
       - Olympiad_Math
       - Olympiad_Science
       - Talent_Test
       - Mathamaze
     ```
```
Day 0 Data load:

SET PGPASSWORD=admin
psql -h 127.0.0.1 -p 5432 -U postgres -d icad_db -f sql/bootstrap_tables.sql
SET PGPASSWORD=admin
psql -h 127.0.0.1 -p 5432 -U postgres -d icad_db -c "\copy student FROM 'seeds/student_existing.csv' CSV HEADER"

SET PGPASSWORD=admin
psql -h 127.0.0.1 -p 5432 -U postgres -d icad_db -c "\copy admission FROM 'seeds/admission_existing.csv' CSV HEADER"


SET PGPASSWORD=admin
psql -h 127.0.0.1 -p 5432 -U postgres -d icad_db -c "\copy student_admissions FROM 'seeds/student_admissions_existing.csv' CSV HEADER"

```