import pandas as pd
from .clean_column_names import clean_column_names
from .clean_strings import clean_string_data

def make_schools_ref(school_ref_df, index_offset=1000):

  school_ref_df = clean_column_names(school_ref_df)

  school_ref_df['institute_name'] = school_ref_df['institute_name'].apply(lambda x: clean_string_data(x))
  school_ref_df['address1'] = school_ref_df['address1'].apply(lambda x: clean_string_data(x))
  school_ref_df['address2'] = school_ref_df['address2'].apply(lambda x: clean_string_data(x))
  school_ref_df['address2'] = school_ref_df['address2'].apply(lambda x: clean_string_data(x))
  school_ref_df['city'] = school_ref_df['city'].apply(lambda x: clean_string_data(x))
  school_ref_df['state'] = school_ref_df['state'].apply(lambda x: clean_string_data(x))

  school_ref_df = school_ref_df.rename_axis('school_id').reset_index()
  school_ref_df['school_id'] = school_ref_df['school_id'] + index_offset

  return school_ref_df