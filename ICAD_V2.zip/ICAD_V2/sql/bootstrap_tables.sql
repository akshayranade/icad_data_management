-- =====================================================
-- Bootstrap SQL for ICAD Ingestion Project
-- Creates the icad_db database and all required tables
-- =====================================================

-- Create database if not exists (Postgres doesn't support IF NOT EXISTS directly, so wrap in DO block)
CREATE DATABASE icad_v2_db;
\c icad_v2_db


-- ========================
-- Student Table
-- ========================
CREATE TABLE IF NOT EXISTS public.student (
    student_id BIGINT PRIMARY KEY,
    student_name TEXT,
    school TEXT,
    standard_school_name TEXT,
    standard_school_id BIGINT,
    class TEXT,
    exam TEXT,
    name_key TEXT
);

-- ========================
-- Admission Table
-- ========================
CREATE TABLE IF NOT EXISTS public.admission (
    admission_id BIGINT PRIMARY KEY,
    student_name TEXT,
    branch TEXT,
    batch TEXT,
    on_roll1 TEXT,
    category TEXT,
    school TEXT,
    xi_college TEXT,
    board_in_10th TEXT,
    board_in_11th_std TEXT,
    name_key TEXT,
    standard_school_name TEXT,
    standard_school_addr TEXT,
    standard_school_city TEXT,
    standard_school_id BIGINT
);

-- ========================
-- School Master Table
-- ========================
CREATE TABLE IF NOT EXISTS public.school (
    school_id BIGINT PRIMARY KEY,
    institute_name TEXT,
    address1 TEXT,
    address2 TEXT,
    city TEXT,
    district TEXT,
    state TEXT,
    board TEXT,
    contact_no TEXT,
    email_address TEXT,
    category TEXT,
    branch_name TEXT
);

-- ========================
-- Student Admissions Table
-- ========================
CREATE TABLE IF NOT EXISTS public.student_admissions (
    student_id BIGINT PRIMARY KEY,
    admission_id BIGINT,
    student_name TEXT,
    branch TEXT,
    branch_name TEXT,
    batch TEXT,
    on_roll1 TEXT,
    school TEXT,
    category TEXT,
    xi_college TEXT,
    board_in_10th TEXT,
    board_in_11th_std TEXT,
    name_key TEXT,
    standard_school_name TEXT,
    standard_school_addr TEXT,
    standard_school_city TEXT,
    standard_school_id BIGINT,
    exam TEXT
);

-- ========================
-- Tracker Table (Processed Files)
-- ========================
CREATE TABLE IF NOT EXISTS public.processed_files (
    file_path TEXT,
    file_hash TEXT PRIMARY KEY,
    processed_at TIMESTAMP DEFAULT now(),
    rows_loaded INT,
    notes TEXT
);
