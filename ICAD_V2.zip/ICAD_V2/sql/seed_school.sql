-- =====================================================
-- Seed Data for School Master
-- =====================================================

\copy public.school(school_id, institute_name, address1, address2, city, district, state, board, contact_no, email_address, category, branch_name) FROM 'seeds/school.csv' DELIMITER ',' CSV HEADER;