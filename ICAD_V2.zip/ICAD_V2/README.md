# ICAD Ingestion Project

## Overview
This project ingests **student** and **admission** data from CSV/Excel files, cleans and enriches them, and loads into PostgreSQL tables.  
The `student_admissions` table is the final enriched table exposed to **PowerBI**.

## Workflow
- **Student file (`student_input.csv`)**
  - Loaded into `student` table.
  - Deduplicated using `name_key`.
  - `student_id` auto-generated.
  - Also inserted into `student_admissions` with `admission_id=NULL`.

- **Admission file (`admission_input.xlsx`)**
  - Loaded into `admission` table.
  - Deduplicated by `admission_id` (`ROLL NO`).
  - Linked to student via `name_key`.
  - Updates existing row in `student_admissions` with admission details.

- **School master (`school`)**
  - Used for enrichment of standard school name/id/address/city.

- **Student_admissions**
  - Always refreshed after each load.
  - Final projection for **PowerBI dashboards**.

## Usage
1. Install requirements:
   ```bash
   pip install -r requirements.txt
   ```

2. Configure database in `config.yaml`.

3. Place input files in the `input/` folder.

4. Run ingestion:
   ```bash
   python main.py run --config config.yaml --schema schema.yaml
   ```

5. Connect PowerBI to `student_admissions` table.

