
import pandas as pd
import numpy as np
from pathlib import Path

from helpers.clean_column_names import clean_column_names
from helpers.clean_strings import clean_string_data
from helpers.get_master_school import get_standard_school

# ----------------------------
# Readers with header auto-fix
# ----------------------------
def _mostly_unnamed(cols):
    cols = [str(c) for c in cols]
    if not cols:
        return True
    unnamed = sum([1 for c in cols if c.strip().lower().startswith("unnamed") or c.strip() == "" or c.strip().lower() == "nan"])
    return unnamed / len(cols) >= 0.5

def _try_excel_with_header(path, header_row):
    try:
        df = pd.read_excel(path, header=header_row)
        # Drop fully empty columns and rows
        df = df.dropna(how="all", axis=0).dropna(how="all", axis=1)
        return df
    except Exception:
        return None

def read_any(path: str, ingest_hints: dict | None = None) -> pd.DataFrame:
    """
    Read CSV/XLSX. For XLSX, auto-detect CPA-style multi-row headers and re-read with header row=2.
    Optional ingest_hints can force a header row per filename pattern.
    """
    p = Path(path)
    if p.suffix.lower() == ".csv":
        return pd.read_csv(p)

    if p.suffix.lower() in (".xlsx", ".xlsm"):
        # 1) hints-based override
        if ingest_hints:
            name = p.name.lower()
            for key, hint in ingest_hints.items():
                pat = hint.get("match", "").lower()
                if pat and pat in name and "header_row" in hint:
                    df = _try_excel_with_header(p, hint["header_row"])
                    if df is not None:
                        return df

        # 2) default read
        df0 = pd.read_excel(p)
        # If the columns look broken, try header=2 (3rd row) which matches CPA sheets
        if _mostly_unnamed(df0.columns):
            df2 = _try_excel_with_header(p, 2)
            if df2 is not None and not _mostly_unnamed(df2.columns):
                return df2
            # also try header=1 as a fallback
            df1 = _try_excel_with_header(p, 1)
            if df1 is not None and not _mostly_unnamed(df1.columns):
                return df1
        # Otherwise keep original
        return df0

    raise ValueError(f"Unsupported file extension: {p.suffix}")

# ----------------------------
# Normalization / typing
# ----------------------------
def standardize_columns(df: pd.DataFrame, standard_cols: list) -> pd.DataFrame:
    df = clean_column_names(df)

    # rename common stray columns
    if "unnamed_0" in df.columns and "admission_id" not in df.columns:
        df = df.rename(columns={"unnamed_0": "admission_id"})

    # add any missing standard columns
    for col in standard_cols:
        if col not in df.columns:
            df[col] = None

    # keep standard columns first
    extra = [c for c in df.columns if c not in standard_cols]
    return df[[*standard_cols, *extra]]

def coerce_types(df: pd.DataFrame, types: dict) -> pd.DataFrame:
    for col, t in types.items():
        if col not in df.columns:
            continue
        if t == "date":
            # placeholder for future date coercion
            pass
        elif t == "numeric":
            df[col] = pd.to_numeric(df[col], errors="coerce")
        elif t == "string":
            df[col] = df[col].astype("string")
    return df

# ----------------------------
# Domain-specific cleaning
# ----------------------------
def clean_text_columns(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    if "school" in df.columns:
        df["school"] = df["school"].apply(lambda x: str(x).replace(",", " ") if pd.notnull(x) else x)

    for col in ("student_name", "city", "school"):
        if col in df.columns:
            df[col] = df[col].apply(lambda x: clean_string_data(x) if pd.notnull(x) else x)
    return df

def clean_class_column(df: pd.DataFrame) -> pd.DataFrame:
    if "class" not in df.columns:
        return df
    s = df["class"].astype(str).str.replace("th", "", case=False, regex=False)
    s = s.replace("-", np.nan)
    s = pd.to_numeric(s, errors="coerce")
    df["class"] = s.dropna().astype(int)
    return df

def compute_name_key(df: pd.DataFrame) -> pd.DataFrame:
    print("compute_name_key",type(df), df)
    if "student_name" not in df.columns:
        df["name_key"] = None
        return df
    df["name_key"] = df["student_name"].apply(lambda s: clean_string_data(str(s)) if pd.notnull(s) else None)
    return df

def derive_exam_from_columns(df: pd.DataFrame, exam_cols: list | None) -> pd.DataFrame:
    if "exam" in df.columns or not exam_cols:
        return df
    missing = [c for c in exam_cols if c not in df.columns]
    if missing:
        return df

    def _row_to_exam(row):
        picked = [col for col in exam_cols if str(row[col]).strip().lower() == "yes"]
        return ", ".join(picked) if picked else None

    df["exam"] = df[exam_cols].apply(_row_to_exam, axis=1)
    return df

# ----------------------------
# School standardization
# ----------------------------
def enrich_with_master_school(df: pd.DataFrame, school_master_df: pd.DataFrame) -> pd.DataFrame:
    if school_master_df is None or len(school_master_df) == 0:
        return df
    df = df.copy()
    if "school" not in df.columns:
        df["school"] = ""

    std_name, std_addr, std_city, std_id = [], [], [], []
    for s in df["school"].fillna("").astype(str):
        n, a, c, i = get_standard_school(s, school_master_df.copy())
        std_name.append(n); std_addr.append(a); std_city.append(c); std_id.append(i)

    df["standard_school_name"]  = std_name
    df["standard_school_addr"]  = std_addr
    df["standard_school_city"]  = std_city
    df["standard_school_id"]    = std_id
    df["branch_name"] = df["standard_school_id"].map(school_master_df.set_index("school_id")["branch_name"])
    return df

# ----------------------------
# Mapping
# ----------------------------
def map_to_targets(df: pd.DataFrame, targets: dict) -> dict:
    out = {}
    for tname, tdef in targets.items():
        cols_map = tdef.get("columns", {})
        rows = []
        for _, r in df.iterrows():
            row = {}
            for tgt_col, src_col in cols_map.items():
                row[tgt_col] = r.get(src_col, None)
            rows.append(row)
        out[tname] = rows
    return out
